<?php

namespace app\models;
use yii\db\ActiveRecord;

class Adminuser extends \yii\db\ActiveRecord
{
   
}
