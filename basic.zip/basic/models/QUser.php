<?php

namespace app\models;
use yii\db\ActiveRecord;

class QUser extends \yii\db\ActiveRecord implements \yii\web\IdentityInterface
{
   public function getAuthKey() {
        return $this->auth_key;
    }

    public function getId() {
        return $this->id;
    }
	

    public function validateAuthKey($authKey) {
       return $this->auth_key = $authkey;
    }

    public static function findIdentity($id) {

        return self::findOne($id);

    }

    public static function findIdentityByAccessToken($token, $type = null) {

        return $this->access_token;
    }

    public static function findByUsername($username){
        return self::findOne(['username'=>$username]);
    }

    public function validatePassword($password){
        return $this->password_hash === $password;
    }
}
