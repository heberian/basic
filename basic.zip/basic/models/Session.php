<?php

namespace app\models;
use yii\db\ActiveRecord;

class Session extends \yii\db\ActiveRecord
{
   
}
