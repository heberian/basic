<?php

namespace app\models;

use yii\db\ActiveRecord;


class User extends ActiveRecord
{

public static function findByUsername($username)
    {
        foreach (self::$users as $user) {
            if (strcasecmp($user['username'], $username) === 0) {
                return new static($user);
            }
        }

        return null;
    }

}

?>