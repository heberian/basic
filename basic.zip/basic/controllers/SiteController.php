<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\IdentityInterface;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;
use app\models\User;
use app\models\Session;

class SiteController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex()
    {
        return $this->render('index');
    }
	
	public function actionSay($target = 'World')
    {
    return $this->render('say', ['target' => $target]);
    }
	public function actionAccount() {
		
		$session = Yii::$app->session;
		if(Yii::$app->session->get('username')=="")
		{			
						
			return $this->redirect(array('site/login'));
		}
		else
		{
			return $this->render('account', ['sessionData' => Yii::$app->session->get('username')]);
			
		}
		
		
	}

    /**
     * Login action.
     *
     * @return string
     */
	public function actionAuth($username,$password) 
	{
 
        $query = User::find();     

        $users = $query->where('username=:username1 and password_hash=:password2', array(':username1'=>$username,':password2'=>$password))->all();     
        
	    return $users;  
    }
	
    public function actionLogin()
    {  
	   $session = Yii::$app->session;
       $session->remove('username');
	   Yii::$app->session->get('username');
       if (!Yii::$app->user->isGuest) {
        return $this->goHome();
       }
	   //var_dump(Yii::$app->request->post());

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && count(self::actionAuth(Yii::$app->request->post('LoginForm')["username"],Yii::$app->request->post('LoginForm')["password"]))=== 1)
		{
			$session = Yii::$app->session;
			$session->set('username', Yii::$app->request->post('LoginForm')["username"]);
			
			$SessionObject = new Session;
			$SessionObject->username = Yii::$app->request->post('LoginForm')["username"];
            
            $SessionObject->save();
			
			
			//return $this->render('account', ['sessionData' => Yii::$app->session->get('username')]);
			return $this->redirect(array('site/account'));
		     
            //return $this->goBack();
        }
        return $this->render('login', [
            'model' => $model,
        ]);
    }

    /**
     * Logout action.
     *
     * @return string
     */
    public function actionLogout()
    {
		
		$session = Yii::$app->session;
        $session->remove('username');
		
        return $this->render('login', [
            'model' => $model,
        ]);
    }

    /**
     * Displays contact page.
     *
     * @return string
     */
    public function actionContact()
    {
        $model = new ContactForm();
        if ($model->load(Yii::$app->request->post()) && $model->contact(Yii::$app->params['adminEmail'])) {
            Yii::$app->session->setFlash('contactFormSubmitted');

            return $this->refresh();
        }
        return $this->render('contact', [
            'model' => $model,
        ]);
    }

    /**
     * Displays about page.
     *
     * @return string
     */
    public function actionAbout()
    {
        return $this->render('about');
    }
}
