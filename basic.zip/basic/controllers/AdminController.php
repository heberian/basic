<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\IdentityInterface;
use yii\filters\VerbFilter;
use app\models\AdminLoginForm;
use app\models\ContactForm;
use app\models\Adminuser;

class AdminController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function actions()
    {
		$this->layout='admin';
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex()
    {
		$this->layout='admin';
        return $this->render('index');
    }
	
	public function actionAccount() {
		
		$session = Yii::$app->session;
		echo Yii::$app->session->get('adminusername');
		if(Yii::$app->session->get('adminusername')=="")
		{			
			$this->layout='admin';			
			return $this->redirect(array('admin/login'));
		}
		else
		{
			$this->layout='admin';
			return $this->render('account', ['adminsessionData' => Yii::$app->session->get('adminusername')]);
			
		}
		
		
	}
	public function actionProduct() 
	{
		//echo "This is product page";
		
		
		$session = Yii::$app->session;
		var_dump($session);
		echo Yii::$app->session->get('loggedasAdmin');
		if(Yii::$app->session->get('loggedasAdmin')=="")
		{			
			$this->layout='admin';			
			//return $this->redirect(array('admin/login'));
		}
		else
		{
			$this->layout='admin';
			//return $this->render('product', ['adminsessionData' => Yii::$app->session->get('loggedasAdmin')]);
			
		}
		
	}
	
	public function actionAuth($username,$password) 
	{
 
        $query = Adminuser::find();     

        $users = $query->where('username=:username1 and password_hash=:password2', array(':username1'=>$username,':password2'=>$password))->all();     
        
	    return $users;  
    }
	
	public function actionLogin()
	{
		
		//$model = new AdminLoginForm();
		//return $this->render('login',['model' => $model]);	
		
	   $session = Yii::$app->session;
       $session->remove('loggedasAdmin');
	   Yii::$app->session->get('loggedasAdmin');
       if (!Yii::$app->user->isGuest) {
        return $this->goHome();
       }
	   //var_dump(Yii::$app->request->post());

        $model = new AdminLoginForm();
        if ($model->load(Yii::$app->request->post()) && count(self::actionAuth(Yii::$app->request->post('AdminLoginForm')["username"],Yii::$app->request->post('AdminLoginForm')["password"]))=== 1)
		{
			$session = Yii::$app->session;
			$session->set('loggedasAdmin', Yii::$app->request->post('AdminLoginForm')["username"]);
			
			//$SessionObject = new Session;
			//$SessionObject->username = Yii::$app->request->post('AdminLoginForm')["username"];
            
            //$SessionObject->save();
			
			
			//return $this->render('account', ['sessionData' => Yii::$app->session->get('username')]);
			$this->layout='admin';
			return $this->redirect(array('admin/account'));
		     
            //return $this->goBack();
        }
        return $this->render('login', [
            'model' => $model,
        ]);
		
		
		
		
		
	}
	public function actionLogout()
	{
		$session = Yii::$app->session();
		
		$session->remove('loggedasAdmin');
		$this->layout='admin';
		
        //return $this->render('login', [
            //'model' => $model,
        //]);
		//return $this->redirect(array('admin/login'));
		
	}
	
	
}
