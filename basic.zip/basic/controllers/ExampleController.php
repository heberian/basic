<?php

namespace app\controllers;
use yii\web\Controller;

class ExampleController extends Controller
{
	public function actionIndex()
	{
		$message = "Index Action of ExampleController";
		return $this->render('index',['message'=>$message]);
	}
}


?>