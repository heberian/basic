<?php

echo $message;

?>