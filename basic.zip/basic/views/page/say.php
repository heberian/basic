<?php
use yii\helpers\Html;
use yii\widgets\LinkPager;
?>
<h1>Hello <?= Html::encode($target) ?></h1>
<h3><?=Html::a( "Lets say something", $url = ['page/say','target' => 'All'], $options = ['title' => 'My Super Link','target' => '_blank','alt' => 'Link to Super Website']); ?></h3>


<p>Welcome to your Yii2 demonstration application.</p>

<p> image using Yii::img </p>

<?//=Html::img( 'images/hqdefault.jpg', $options = [] )?>

<h1>Countries</h1>
<ul>
<?php foreach ($countries as $country): ?>
    <li>
        <?= Html::encode("{$country->name} ({$country->code})") ?>:
        <?= $country->population ?>
    </li>
<?php endforeach; ?>
</ul>
<?= LinkPager::widget(['pagination' => $pagination]) ?>
